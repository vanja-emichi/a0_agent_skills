"""Phase 0 — subordinate prompt resolution tests.

Verifies that the plugin override mechanism for agent profiles works correctly:

1. Agent0 profile resolves the override specifics (skill discovery, DOX awareness, subordinate delegation)
2. Subordinate profiles (developer, test-engineer, etc.) do NOT get the override
3. Both agent0 and subordinate profiles get the DOX interpreter content
4. Agent numbering is correct (agent0=0, subordinates=1+)

Split into:
- TestPromptOverrideStructure: file-level structural checks (plugin venv)
- TestPromptOverrideRuntime: framework prompt resolution (A0 runtime venv)
- TestPromptOverrideE2E: live server behavioral tests (e2e marker)

All e2e tests skip automatically when the Agent Zero server is not running.
Runtime tests skip when the A0 runtime venv (langchain_core) is not available.
"""

from __future__ import annotations

import importlib.util
import sys
import uuid
from pathlib import Path
from types import SimpleNamespace

import pytest

from tests.e2e._a0_e2e_client import A0E2EClient, gather_evidence, extract_response_text as _extract_response_text

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

PLUGIN_DIR = Path("/a0/usr/plugins/a0_agent_skills")

# Override marker — used for negative assertions (subordinates must NOT have it)
SKILL_DISCOVERY_MARKER = "skill discovery"

# agent0 override and DOX interpreter removed per ADR-008 follow-up;
# protocol is now baked into root AGENTS.md files.
FRAMEWORK_AGENT0_SPECIFICS = (
    Path("/a0/agents/agent0/prompts/agent.system.main.specifics.md")
)
FRAMEWORK_DEVELOPER_SPECIFICS = (
    Path("/a0/agents/developer/prompts/agent.system.main.specifics.md")
)
# DOX interpreter removed — protocol now baked into root AGENTS.md files

# Subordinate profiles shipped by the plugin
PLUGIN_PROFILES = ["code-reviewer", "security-auditor", "test-engineer"]

# ---------------------------------------------------------------------------
# Structural tests (plugin venv, no framework deps)
# ---------------------------------------------------------------------------


class TestPromptOverrideStructure:
    """Validate shipped override files and profile specifics."""

    def test_framework_agent0_specifics_lacks_override(self):
        """Framework default agent0 specifics does NOT contain the override."""
        if not FRAMEWORK_AGENT0_SPECIFICS.is_file():
            pytest.skip("Framework agent0 specifics not found")
        content = FRAMEWORK_AGENT0_SPECIFICS.read_text(encoding="utf-8")
        assert SKILL_DISCOVERY_MARKER not in content.lower(), (
            f"Framework specifics should NOT contain '{SKILL_DISCOVERY_MARKER}'"
        )

    def test_developer_specifics_lacks_override(self):
        """Developer profile specifics do NOT contain the override."""
        if not FRAMEWORK_DEVELOPER_SPECIFICS.is_file():
            pytest.skip("Framework developer specifics not found")
        content = FRAMEWORK_DEVELOPER_SPECIFICS.read_text(encoding="utf-8")
        assert SKILL_DISCOVERY_MARKER not in content.lower(), (
            f"Developer specifics should NOT contain '{SKILL_DISCOVERY_MARKER}'"
        )

    def test_plugin_profile_specifics_lack_override(self):
        """All plugin-shipped profile specifics (non-agent0) lack the override."""
        for profile in PLUGIN_PROFILES:
            specifics = (
                PLUGIN_DIR / "agents" / profile / "prompts"
                / "agent.system.main.specifics.md"
            )
            if not specifics.is_file():
                continue
            content = specifics.read_text(encoding="utf-8")
            assert SKILL_DISCOVERY_MARKER not in content.lower(), (
                f"Profile '{profile}' specifics should NOT contain '{SKILL_DISCOVERY_MARKER}'. "
                f"File: {specifics}"
            )


# ---------------------------------------------------------------------------
# Runtime integration tests (A0 runtime venv with langchain_core)
# ---------------------------------------------------------------------------

_HAS_A0_RUNTIME = importlib.util.find_spec("langchain_core") is not None

A0_ROOT = Path("/a0")

if str(A0_ROOT) not in sys.path:
    sys.path.insert(0, str(A0_ROOT))


def _clear_runtime_caches():
    try:
        from helpers import cache
        for area in ("*(plugins)*", "*(subagent)*"):
            try:
                cache.clear(area)
            except Exception:
                pass
    except ImportError:
        pass


@pytest.fixture(autouse=True)
def clear_caches():
    _clear_runtime_caches()
    yield
    _clear_runtime_caches()


class FakeContext:
    id = "prompt-override-test"

    def __init__(self):
        self.log = SimpleNamespace(logs=[])

    def get_data(self, key, default=None):
        return default


class FakeAgent:
    """Minimal agent stub that delegates read_prompt to the real framework."""

    def __init__(self, profile: str, number: int = 0):
        self.agent_name = profile
        self.number = number
        self.config = SimpleNamespace(profile=profile)
        self.data = {}
        self.context = FakeContext()

    def read_prompt(self, name, **kwargs):
        from helpers import files, subagents
        dirs = subagents.get_paths(self, "prompts")
        return files.read_prompt_file(
            name, _directories=dirs, _agent=self, **kwargs
        )


@pytest.mark.runtime_integration
@pytest.mark.skipif(not _HAS_A0_RUNTIME, reason="A0 runtime venv required (langchain_core)")
class TestPromptOverrideRuntime:
    """Framework-level prompt resolution for profile overrides."""

    def test_developer_does_not_resolve_override(self):
        """Developer profile specifics do NOT contain skill discovery override."""
        agent = FakeAgent(profile="developer", number=1)
        prompt = agent.read_prompt("agent.system.main.specifics.md")
        assert SKILL_DISCOVERY_MARKER not in (prompt or "").lower(), (
            f"Developer specifics should NOT contain '{SKILL_DISCOVERY_MARKER}'. "
            f"Got: {prompt[:200] if prompt else '(empty)'}"
        )

    def test_test_engineer_does_not_resolve_override(self):
        """Test-engineer profile specifics do NOT contain skill discovery override."""
        agent = FakeAgent(profile="test-engineer", number=1)
        prompt = agent.read_prompt("agent.system.main.specifics.md")
        assert SKILL_DISCOVERY_MARKER not in (prompt or "").lower(), (
            f"test-engineer specifics should NOT contain '{SKILL_DISCOVERY_MARKER}'. "
            f"Got: {prompt[:200] if prompt else '(empty)'}"
        )

    def test_code_reviewer_does_not_resolve_override(self):
        """Code-reviewer profile specifics do NOT contain skill discovery override."""
        agent = FakeAgent(profile="code-reviewer", number=1)
        prompt = agent.read_prompt("agent.system.main.specifics.md")
        assert SKILL_DISCOVERY_MARKER not in (prompt or "").lower(), (
            f"code-reviewer specifics should NOT contain '{SKILL_DISCOVERY_MARKER}'. "
            f"Got: {prompt[:200] if prompt else '(empty)'}"
        )

    def test_security_auditor_does_not_resolve_override(self):
        """Security-auditor profile specifics do NOT contain skill discovery override."""
        agent = FakeAgent(profile="security-auditor", number=1)
        prompt = agent.read_prompt("agent.system.main.specifics.md")
        assert SKILL_DISCOVERY_MARKER not in (prompt or "").lower(), (
            f"security-auditor specifics should NOT contain '{SKILL_DISCOVERY_MARKER}'. "
            f"Got: {prompt[:200] if prompt else '(empty)'}"
        )

@pytest.mark.e2e
@pytest.mark.dox_behavioral
class TestPromptOverrideE2E:
    """E2e tests proving prompt override behavior through live tasks."""

    def test_subordinate_does_not_see_override(
        self, a0_client: A0E2EClient, task_tracker, clean_tasks
    ):
        """Subordinate with developer profile does NOT see skill discovery override."""
        uid = uuid.uuid4().hex[:8]
        task = a0_client.create_and_run_task(
            name=f"e2e-override-sub-{uid}",
            system_prompt=(
                "You are a test agent. Use call_subordinate when asked. "
                "Report the subordinate's response verbatim."
            ),
            prompt=(
                "Use call_subordinate with profile 'developer' and message: "
                "'Check your system prompt for the specific auto-loaded section titled 'Agent Skills' or text containing 'Follow its skill discovery tree for all tasks'. "
                "If you see that specific auto-loaded injection text, respond SUB_HAS_AUTOLOAD. "
                "If you do NOT see that specific auto-loaded injection text, respond SUB_NO_AUTOLOAD. Note: a generic '## skills' listing is NOT the same as the auto-loaded injection. "
                "'\n"
                "In your final response, include the subordinate's exact response."
            ),
        )
        task_tracker.append(task["uuid"])
        result = a0_client.wait_for_task(task["uuid"], timeout=600)

        assert result.get("state") == "idle", f"Task ended in state {result.get('state')}"

        evidence = gather_evidence(a0_client, result)
        response = _extract_response_text(evidence["last_response"])

        # Subordinate should NOT have the override
        assert "SUB_NO_AUTOLOAD" in response, (
            f"Subordinate should report no skill discovery content. "
            f"Response (last 500): ...{response[-500:]}"
        )
        # Subordinate should NOT have the override marker in any form
        assert "SUB_HAS_SKILL_DISCOVERY" not in response, (
            f"Subordinate should NOT report having skill discovery override. "
            f"Response (last 500): ...{response[-500:]}"
        )

