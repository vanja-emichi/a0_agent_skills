"""Activate agent skills when using-agent-skills is loaded.

When any agent loads the `using-agent-skills` meta-skill via skills_tool,
this extension sets `agent_skills_enabled: true` in the active project's
project.json. This makes skill activation bidirectional:

1. First session: agent discovers and loads `using-agent-skills` → flag set
2. Subsequent sessions: `message_loop_start` extension sees the flag and
   auto-loads the meta-skill at session start

This reverses the dependency: instead of requiring the flag first, loading
the skill IS the activation.
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any

from helpers.extension import Extension

logger = logging.getLogger(__name__)

META_SKILL_NAME = "using-agent-skills"


def _project_json_path(project_name: str) -> str | None:
    """Return the project.json path for a project, or None if not found."""
    try:
        from helpers import projects
        folder = projects.get_project_folder(project_name)
    except Exception:
        return None
    if not folder:
        return None
    path = os.path.join(folder, ".a0proj", "project.json")
    return path if os.path.isfile(path) else None


class ActivateOnSkillLoad(Extension):

    def execute(
        self,
        response: Any = None,
        tool_name: str = "",
        **kwargs: Any,
    ):
        if not self.agent:
            return

        if tool_name != "skills_tool":
            return

        if not response or not hasattr(response, "message"):
            return

        message = response.message or ""
        if META_SKILL_NAME not in message:
            return

        # Get active project
        project_name = self.agent.context.get_data("project")
        if not project_name:
            return

        project_json_path = _project_json_path(project_name)
        if not project_json_path:
            return

        try:
            with open(project_json_path, encoding="utf-8") as f:
                data = json.load(f)

            if data.get("agent_skills_enabled") is True:
                return  # Already enabled

            data["agent_skills_enabled"] = True
            with open(project_json_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)

            logger.info(
                "[skill-activate] Set agent_skills_enabled=true for project '%s' "
                "after loading '%s'",
                project_name,
                META_SKILL_NAME,
            )
        except Exception as e:
            logger.warning("[skill-activate] Failed to set flag: %s", e)
