# tests

## Purpose

Test suite for the a0_agent_skills plugin: structural/schema tests, isolated unit tests, and e2e behavioral tests. Most non-e2e tests live at the `tests/` root level; e2e tests live in `tests/e2e/`.

## Ownership

Project team.

## Local Contracts

- `conftest.py` — shared pytest fixtures for all tiers
- `tests/` root — structural, runtime integration, and isolated import tests (no server required for structural tests):
  - `test_structure.py` — plugin file layout and YAML schema validation
  - `test_sdd_cache.py` — SDD cache extension logic
  - `test_simplify_ignore.py` — simplify-ignore extension logic
  - `test_ship_command.py` — ship command rendering
  - `test_eval_report.py` — eval report generation
  - `test_extension_imports_isolated.py` — extension import isolation checks
  - `test_message_loop_start.py` — message loop start extension
  - `test_runtime_commands.py` — runtime command tests (marked `@pytest.mark.runtime_integration`)
  - `test_runtime_extensions_and_hooks.py` — runtime extension/hook tests (marked `@pytest.mark.runtime_integration`)
  - `test_runtime_skills_and_agents.py` — runtime skill/agent tests (marked `@pytest.mark.runtime_integration`)
- `e2e/` — live API behavioral tests requiring Agent Zero server on port 80
- `structural/` — organizational boundary for future structural tests (currently no test files)
- `unit/` — organizational boundary for future unit tests (currently no test files)
- `pytest.ini` at plugin root configures markers: `e2e`, `runtime_integration`, `structural`

## Work Guidance

- New structural/schema tests go in `tests/` root or `structural/`
- New isolated logic tests go in `tests/` root or `unit/`
- New behavioral/API tests go in `e2e/`
- Prefer root-level and unit tests over e2e when the behavior can be tested without a server
- Runtime integration tests require `/opt/venv-a0/bin/python` with the A0 framework

## Verification

```bash
# All non-e2e tests (structural + unit + root-level)
/opt/venv/bin/python -m pytest tests -v -m 'not e2e' -q

# E2e (requires live server)
/opt/venv/bin/python -m pytest tests/e2e -v -m e2e
```

## Child DOX Index

| Child | Scope |
|---|---|
| `unit/AGENTS.md` | Isolated unit tests boundary |
| `structural/AGENTS.md` | Schema and compliance tests boundary |
| `e2e/AGENTS.md` | Live API behavioral tests |
