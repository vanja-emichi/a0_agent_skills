# tests/unit

## Purpose

Isolated unit tests for individual skills, extensions, and Python utilities. No live Agent Zero server required.

## Ownership

Project team. Add tests here for any logic that can be tested without a running server.

## Local Contracts

- Tests must not import or require the live Agent Zero HTTP API
- Use standard pytest fixtures; no `_a0_e2e_client.py`
- Cover skill YAML parsing, extension hook logic, command rendering logic

## Work Guidance

- Currently, isolated logic tests live at `tests/` root level (`test_sdd_cache.py`, `test_simplify_ignore.py`, etc.)
- This directory serves as an organizational boundary for future dedicated unit test modules
- New unit tests that need pytest fixtures go here

## Verification

```bash
/opt/venv/bin/python -m pytest tests/unit -q
```

## Child DOX Index

No child DOX files.
