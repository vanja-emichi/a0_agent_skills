"""Structural tests for ADR-011 message_loop_start extension and related files.

Validates that the extension, override, commands, and template files
exist with the expected content and guard clauses.
"""

from __future__ import annotations

import os

import pytest

PLUGIN_DIR = os.path.normpath(os.path.join(os.path.dirname(__file__), ".."))


# ---------------------------------------------------------------------------
# Extension with agent-0 guard
# ---------------------------------------------------------------------------


class TestAgentInitExtension:
    """Validate the message_loop_start extension for ADR-011."""

    EXTENSION_PATH = os.path.join(
        PLUGIN_DIR,
        "extensions",
        "python",
        "message_loop_start",
        "_10_load_using_agent_skills.py",
    )

    @pytest.fixture()
    def extension_content(self):
        with open(self.EXTENSION_PATH, encoding="utf-8") as f:
            return f.read()

    def test_extension_exists(self):
        """Extension file exists in message_loop_start hook directory."""
        assert os.path.isfile(self.EXTENSION_PATH), (
            f"Extension not found: {self.EXTENSION_PATH}"
        )

    def test_extension_has_agent_number_guard(self, extension_content):
        """Extension guards on agent.number to only run for agent 0."""
        assert "agent.number" in extension_content or '"number"' in extension_content, (
            "Extension must check agent.number to guard against subordinate auto-load"
        )

    def test_extension_references_using_agent_skills(self, extension_content):
        """Extension references the using-agent-skills meta-skill."""
        assert "using-agent-skills" in extension_content, (
            "Extension must reference 'using-agent-skills' meta-skill"
        )


# ---------------------------------------------------------------------------
# Override trimmed
# ---------------------------------------------------------------------------


class TestCommandFiles:
    """Validate use-agent-skills command files exist."""

    def test_yaml_exists(self):
        """use-agent-skills.command.yaml exists."""
        path = os.path.join(
            PLUGIN_DIR, "commands", "use-agent-skills.command.yaml"
        )
        assert os.path.isfile(path), f"Command YAML not found: {path}"

    def test_script_exists(self):
        """use_agent_skills.py script exists."""
        path = os.path.join(
            PLUGIN_DIR, "commands", "use_agent_skills.py"
        )
        assert os.path.isfile(path), f"Command script not found: {path}"


# ---------------------------------------------------------------------------
# Template with 6 phases
# ---------------------------------------------------------------------------


class TestProjectTemplate:
    """Validate project template exists and is clean."""

    TEMPLATE_PATH = os.path.join(
        PLUGIN_DIR, "templates", "project", "AGENTS.md"
    )

    def test_template_exists(self):
        """Project template AGENTS.md exists."""
        assert os.path.isfile(self.TEMPLATE_PATH), (
            f"Template not found: {self.TEMPLATE_PATH}"
        )
