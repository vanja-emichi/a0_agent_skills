# tests/structural

## Purpose

Structural and schema validation tests. Verify plugin file layout, AGENTS.md compliance, skill YAML schema, and other static correctness checks. No live server required.

## Ownership

Project team. Complements the standalone `node scripts/validate-skills.js` check with pytest-compatible structural tests.

## Local Contracts

- Tests must not require a live server
- Validate file existence, YAML schema correctness, AGENTS.md section presence
- `node scripts/validate-skills.js` remains valid; structural pytest tests complement it

## Work Guidance

- Currently, structural tests live at `tests/` root level (`test_structure.py`)
- This directory serves as an organizational boundary for future dedicated structural test modules
- New schema/compliance tests that need pytest fixtures go here

## Verification

```bash
/opt/venv/bin/python -m pytest tests/structural -q
```

## Child DOX Index

No child DOX files.
