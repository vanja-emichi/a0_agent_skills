"""Auto-load the using-agent-skills meta-skill for agent 0.

When a project opts in via `agent_skills_enabled: true` in project.json,
this extension:

1. Registers the skill in `agent.data['loaded_skills']` (so it's available)
2. Injects a system message telling the agent the skill was auto-loaded
   and to follow its discovery tree for all tasks

Only runs for agent number 0 on the first message loop iteration.
"""

from __future__ import annotations

import logging

from helpers.extension import Extension

logger = logging.getLogger(__name__)

DATA_NAME_LOADED_SKILLS = "loaded_skills"
META_SKILL = "using-agent-skills"
PRIME_KEY = "_agent_skills_primed"


class LoadUsingAgentSkills(Extension):

    def execute(self, **kwargs):
        """Auto-load using-agent-skills for agent 0 when the project opts in."""
        # Only run on first loop iteration (iteration 0)
        loop_data = kwargs.get("loop_data")
        iteration = getattr(loop_data, "iteration", -1) if loop_data else -1
        if iteration != 0:
            return

        if not self.agent:
            return

        # Only for main agent
        agent_number = getattr(self.agent, "number", -1)
        if agent_number != 0:
            return

        # Check if already primed (avoid re-priming on context reload)
        if self.agent.data.get(PRIME_KEY):
            return

        # Read project opt-in
        project_name = self.agent.context.get_data("project")
        if not project_name:
            return

        try:
            from helpers.projects import load_project_header
            header = load_project_header(project_name)
        except Exception as e:
            logger.warning("[skill-load] load_project_header failed: %s", e)
            return

        enabled = header.get("agent_skills_enabled")
        if not enabled:
            return

        # Mark as primed so we don't re-prime
        self.agent.data[PRIME_KEY] = True

        # 1. Register skill in loaded_skills (so _65_include_loaded_skills renders it)
        data = getattr(self.agent, "data", None)
        if isinstance(data, dict):
            loaded = data.get(DATA_NAME_LOADED_SKILLS)
            if not isinstance(loaded, list):
                loaded = []
                data[DATA_NAME_LOADED_SKILLS] = loaded
            if META_SKILL not in loaded:
                loaded.append(META_SKILL)

        # 2. Inject instruction via extras_persistent (part of every system prompt)
        if loop_data is not None:
            loop_data.extras_persistent["agent_skills_auto_loaded"] = (
                "# Agent Skills (auto-loaded)\n"
                "The `using-agent-skills` skill has been auto-loaded for this project. "
                "Follow its skill discovery tree for all tasks — it governs how other "
                "skills are found and applied. Check for applicable skills before "
                "starting any work.\n"
            )

        logger.info("[skill-load] Auto-loaded %s for agent 0 in project %s", META_SKILL, project_name)
