# tool_execute_after Extensions

## Purpose

Extensions that fire after any tool executes, providing post-execution hooks for caching, skill activation, and state updates.

## Ownership

- `_10_sdd_cache.py`: Source-driven development cache — caches documentation lookups so repeated source-driven queries return cached results instead of re-fetching.
- `_20_activate_on_skill_load.py`: Bidirectional skill activation — when any agent loads `using-agent-skills` via skills_tool, sets `agent_skills_enabled: true` in the active project's project.json so future sessions auto-load the meta-skill.

## Local Contracts

- SDD cache keys are based on query hash + source URL.
- Skill activation extension only fires when the tool that just executed was `skills_tool` with action `load` and skill_name `using-agent-skills`.
- Both extensions are no-ops when their conditions are not met.

## Work Guidance

- Add new post-execution hooks by creating `_NN_<name>.py` with the next available prefix number.
- Keep hooks focused on a single concern and idempotent — tool calls may be retried.

## Verification

- `tests/test_sdd_cache.py` covers SDD cache behavior.
- `tests/test_runtime_extensions_and_hooks.py` covers skill lifecycle and activation extensions.
- `tests/e2e/test_e2e_extensions.py` and `tests/e2e/test_e2e_extension_behavior.py` cover live integration.

## Child DOX Index

No child DOX files.
