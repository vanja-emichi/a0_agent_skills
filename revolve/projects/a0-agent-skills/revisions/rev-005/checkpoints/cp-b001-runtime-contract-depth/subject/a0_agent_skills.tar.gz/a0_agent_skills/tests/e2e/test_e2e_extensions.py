"""E2e tests for Agent Zero plugin extensions.

Tests that plugin extensions (SDD cache, simplify-ignore, skill auto-unload)
work correctly in a live agent session.

Prerequisites:
    - Agent Zero server running (auto-detected by conftest)
    - A0_E2E_USERNAME / A0_E2E_PASSWORD environment variables set
    - a0_agent_skills plugin installed
"""

from __future__ import annotations

import pytest

from tests.e2e._a0_e2e_client import A0E2EClient, gather_evidence

pytestmark = pytest.mark.e2e


@pytest.fixture(scope="module")
def client(a0_client: A0E2EClient) -> A0E2EClient:
    return a0_client


# ------------------------------------------------------------------
# Test: Meta-skill content in agent0 specifics override
# ------------------------------------------------------------------

class TestMetaSkillSpecificsOverride:
    """Verify the agent0 override was removed per ADR-008 follow-up.

    The plugin previously shipped an agent0 specifics override at
    ``agents/agent0/prompts/agent.system.main.specifics.md``.  Per
    ADR-008 follow-up, the override feature was removed and the protocol
    is now baked into root AGENTS.md files.
    """

    def test_specifics_override_file_absent(self):
        """Verify the specifics override file does NOT exist in the plugin."""
        import os
        path = "/a0/usr/plugins/a0_agent_skills/agents/agent0/prompts/agent.system.main.specifics.md"
        assert not os.path.isfile(path), (
            f"Specifics override file should not exist (removed per ADR-008): {path}"
        )


# ------------------------------------------------------------------
# Test: Extension files are present and valid
# ------------------------------------------------------------------

class TestExtensionFilePresence:
    """Verify all extension files exist and are valid Python."""

    EXPECTED_EXTENSIONS = [
        "extensions/python/monologue_end/_10_simplify_ignore.py",
        "extensions/python/monologue_end/_15_skill_auto_unload.py",
        "extensions/python/text_editor_patch_after/_10_simplify_ignore.py",
        "extensions/python/text_editor_write_after/_10_simplify_ignore.py",
        "extensions/python/tool_execute_after/_10_sdd_cache.py",
        "extensions/python/tool_execute_after/_20_activate_on_skill_load.py",
        "extensions/python/tool_execute_before/_10_sdd_cache.py",
        "extensions/python/tool_execute_before/_20_simplify_ignore.py",
        "extensions/python/message_loop_start/_10_load_using_agent_skills.py",
    ]

    def test_all_extension_files_present(self):
        """Verify all extension files exist in the plugin directory."""
        import os
        plugin_dir = "/a0/usr/plugins/a0_agent_skills"
        for ext_path in self.EXPECTED_EXTENSIONS:
            full_path = os.path.join(plugin_dir, ext_path)
            assert os.path.isfile(full_path), f"Extension file missing: {ext_path}"

    def test_all_extension_files_compile(self):
        """Verify all extension files are valid Python."""
        import py_compile
        import os
        plugin_dir = "/a0/usr/plugins/a0_agent_skills"
        for ext_path in self.EXPECTED_EXTENSIONS:
            full_path = os.path.join(plugin_dir, ext_path)
            py_compile.compile(full_path, doraise=True)
