"""E2E skill coverage tests via HTTP API.

Closes the coverage gap where only 6 of 24 skills were referenced in e2e
tests.  This module verifies:

1. **Loading coverage** — every one of the 24 installed skills loads via
   ``skills_tool`` without errors and returns SKILL.md content.
2. **Discovery coverage** — high-signal trigger phrases resolve to the
   correct skill through ``skills_tool`` search.
3. **Negative handling** — a nonexistent skill name fails gracefully
   without crashing the agent.

All tests skip automatically when the Agent Zero server is not running.
"""

from __future__ import annotations

import uuid

import pytest

from tests.e2e._a0_e2e_client import (
    A0E2EClient,
    A0E2EClientError,
    extract_response_text,
    gather_evidence,
)

pytestmark = [pytest.mark.e2e, pytest.mark.dox_behavioral]

# ---------------------------------------------------------------------------
# Full list of installed skills (kept in sync with skills/ directory)
# ---------------------------------------------------------------------------

ALL_SKILLS = [
    "api-and-interface-design",
    "browser-testing-with-devtools",
    "ci-cd-and-automation",
    "code-review-and-quality",
    "code-simplification",
    "context-engineering",
    "debugging-and-error-recovery",
    "deprecation-and-migration",
    "documentation-and-adrs",
    "doubt-driven-development",
    "frontend-ui-engineering",
    "git-workflow-and-versioning",
    "idea-refine",
    "incremental-implementation",
    "interview-me",
    "observability-and-instrumentation",
    "performance-optimization",
    "planning-and-task-breakdown",
    "security-and-hardening",
    "shipping-and-launch",
    "source-driven-development",
    "spec-driven-development",
    "test-driven-development",
    "using-agent-skills",
]

_SYSTEM_PROMPT = (
    "You are a test agent. Use tools as instructed. "
    "Always include the results of tool calls in your response text."
)


def _run_task_and_get_response(
    a0_client: A0E2EClient,
    task_tracker: list[str],
    name: str,
    prompt: str,
    timeout: int = 600,
) -> tuple[dict, str]:
    """Create+run a task, wait, and return (evidence_dict, response_text).

    Shared helper for coverage tests.  Handles task lifecycle, tracking,
    and response text extraction so each test focuses on assertions.
    """
    task = a0_client.create_and_run_task(
        name=name,
        system_prompt=_SYSTEM_PROMPT,
        prompt=prompt,
    )
    task_tracker.append(task["uuid"])

    result = a0_client.wait_for_task(task["uuid"], timeout=timeout)

    # Layer 1: task reached idle state
    assert result.get("state") == "idle", (
        f"Task '{name}' ended in state {result.get('state')}"
    )

    evidence = gather_evidence(a0_client, result)
    response_text = extract_response_text(evidence["last_response"])

    return evidence, response_text


# ---------------------------------------------------------------------------
# Level 1 — every skill loads
# ---------------------------------------------------------------------------

@pytest.mark.e2e
class TestSkillLoadingCoverage:
    """Verify every skill loads via skills_tool without errors."""

    @pytest.mark.parametrize(
        "skill_name",
        ALL_SKILLS,
        ids=[f"load-{s}" for s in ALL_SKILLS],
    )
    def test_skill_loads_successfully(
        self,
        a0_client: A0E2EClient,
        task_tracker: list[str],
        clean_tasks,
        skill_name: str,
    ):
        """Each skill should load via skills_tool and return SKILL.md content."""
        uid = uuid.uuid4().hex[:8]
        evidence, response_text = _run_task_and_get_response(
            a0_client,
            task_tracker,
            name=f"e2e-skill-coverage-load-{skill_name}-{uid}",
            prompt=(
                f'1. Use skills_tool with action "load" and skill_name "{skill_name}".\n'
                f"2. In your final response, confirm the skill loaded successfully "
                f"and describe what the skill is about in one sentence."
            ),
        )

        # Layer 2: response text is meaningful (>20 chars)
        assert len(response_text) > 20, (
            f"Response too short for skill '{skill_name}': {response_text!r}"
        )

        # Layer 3: no unexpected errors in logs
        assert evidence["log_errors"] == 0, (
            f"Unexpected errors in logs for skill '{skill_name}': "
            f"{evidence['log_errors']}"
        )


# ---------------------------------------------------------------------------
# Level 2 — discovery via trigger phrases
# ---------------------------------------------------------------------------

@pytest.mark.e2e
class TestSkillDiscoveryCoverage:
    """Verify skill discovery works for high-signal triggers."""

    @pytest.mark.parametrize(
        "trigger,expected_skill",
        [
            ("write unit tests", "test-driven-development"),
            ("debug this error", "debugging-and-error-recovery"),
            ("review this code", "code-review-and-quality"),
            ("plan this feature", "planning-and-task-breakdown"),
            ("security vulnerability", "security-and-hardening"),
        ],
        ids=[
            "trigger-tests",
            "trigger-debug",
            "trigger-review",
            "trigger-planning",
            "trigger-security",
        ],
    )
    def test_trigger_finds_correct_skill(
        self,
        a0_client: A0E2EClient,
        task_tracker: list[str],
        clean_tasks,
        trigger: str,
        expected_skill: str,
    ):
        """skills_tool search should find the right skill for high-signal triggers."""
        uid = uuid.uuid4().hex[:8]
        evidence, response_text = _run_task_and_get_response(
            a0_client,
            task_tracker,
            name=f"e2e-skill-coverage-discover-{expected_skill}-{uid}",
            prompt=(
                f'Use skills_tool with action "search" and query "{trigger}". '
                f"In your final response, report the top skill name found. "
                f"Make sure the exact skill name appears in your response."
            ),
        )

        response_lower = response_text.lower()
        assert expected_skill in response_lower, (
            f"Expected '{expected_skill}' in response for trigger '{trigger}'. "
            f"Got: {response_text[:500]}"
        )

        # Layer 3: no unexpected errors
        assert evidence["log_errors"] == 0, (
            f"Unexpected errors for trigger '{trigger}': {evidence['log_errors']}"
        )


# ---------------------------------------------------------------------------
# Level 3 — negative: nonexistent skill
# ---------------------------------------------------------------------------

@pytest.mark.e2e
class TestSkillLoadingNegative:
    """Verify nonexistent skills fail gracefully."""

    def test_nonexistent_skill_handles_error(
        self,
        a0_client: A0E2EClient,
        task_tracker: list[str],
        clean_tasks,
    ):
        """Loading a nonexistent skill should not crash the agent."""
        uid = uuid.uuid4().hex[:8]
        evidence, response_text = _run_task_and_get_response(
            a0_client,
            task_tracker,
            name=f"e2e-skill-coverage-negative-{uid}",
            prompt=(
                'Try to load skill "nonexistent-fake-skill" using skills_tool '
                'with action "load". '
                "Report what happens in your final response."
            ),
        )

        response_lower = response_text.lower()
        # Agent should handle gracefully, not crash — response should mention
        # some form of error/not-found/no-skill
        assert any(
            marker in response_lower
            for marker in ("error", "not found", "no skill", "doesn't exist",
                           "does not exist", "not available", "unable", "invalid")
        ), (
            f"Expected error/not-found indicator for nonexistent skill. "
            f"Got: {response_text[:500]}"
        )

        # Layer 3: the task itself should complete without log errors —
        # a graceful 'skill not found' is expected behavior, not a crash
        assert evidence["log_errors"] == 0, (
            f"Unexpected log errors for nonexistent skill: {evidence['log_errors']}"
        )
