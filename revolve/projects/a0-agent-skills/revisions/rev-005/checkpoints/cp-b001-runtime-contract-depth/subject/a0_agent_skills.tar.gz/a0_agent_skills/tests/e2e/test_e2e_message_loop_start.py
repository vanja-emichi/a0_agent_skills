"""E2e tests for ADR-011 message_loop_start extension — using-agent-skills auto-load.

Tests that the `using-agent-skills` meta-skill is auto-loaded for agent 0
when the project has opted in, and that subordinates do NOT receive the
auto-load.

Evidence model:

  Layer 1 — Task lifecycle: scheduler task reaches idle state
  Layer 2 — loaded_skills in chat.json: contains / does not contain the skill
  Layer 3 — Runtime logs: no unexpected errors

All tests skip automatically when the Agent Zero server is not running.
"""

from __future__ import annotations

import json
import os
import shutil
import uuid
from pathlib import Path
from typing import Any

import pytest

from tests.e2e._a0_e2e_client import A0E2EClient, A0E2EClientError, gather_evidence

pytestmark = pytest.mark.e2e

PROJECTS_ROOT = Path("/a0/usr/projects")


def _create_opted_in_project(a0_client: A0E2EClient) -> tuple[str, str]:
    """Create a temporary A0 project with agent_skills_enabled: true.

    Returns (project_name, project_dir).
    """
    project_name = f"e2e-agent-init-{uuid.uuid4().hex[:8]}"
    project_dir = PROJECTS_ROOT / project_name
    project_dir.mkdir(parents=True, exist_ok=True)

    # Create .a0proj with agent_skills_enabled
    a0proj_dir = project_dir / ".a0proj"
    a0proj_dir.mkdir(parents=True, exist_ok=True)
    project_json = {
        "title": f"E2E Test {project_name}",
        "description": "Temporary project for message_loop_start e2e test",
        "instructions": "",
        "include_agents_md": True,
        "agent_skills_enabled": True,
    }
    (a0proj_dir / "project.json").write_text(
        json.dumps(project_json, indent=2), encoding="utf-8"
    )

    # Create a minimal AGENTS.md so the project loads cleanly
    (project_dir / "AGENTS.md").write_text(
        "# E2E Agent Init Test\n\n## Purpose\n\nTemporary test fixture.\n",
        encoding="utf-8",
    )

    return project_name, str(project_dir)


def _cleanup_project(project_dir: str) -> None:
    """Remove the temporary project directory."""
    p = Path(project_dir)
    if p.exists() and p.is_dir() and p.name.startswith("e2e-agent-init-"):
        shutil.rmtree(p, ignore_errors=True)


def _get_loaded_skills_for_agent(
    a0_client: A0E2EClient, context_id: str, agent_index: int = 0
) -> list[str]:
    """Extract loaded_skills from a specific agent in chat.json.

    Returns the loaded_skills list, or an empty list if unavailable.
    """
    chat = a0_client.get_chat_json(context_id)
    if not chat:
        return []

    agents = chat.get("agents", [])
    if agent_index >= len(agents):
        return []

    data = agents[agent_index].get("data", {})
    return data.get("loaded_skills", [])


def _get_all_agent_loaded_skills(
    a0_client: A0E2EClient, context_id: str
) -> list[list[str]]:
    """Extract loaded_skills from ALL agents in chat.json.

    Returns a list of loaded_skills lists, one per agent.
    """
    chat = a0_client.get_chat_json(context_id)
    if not chat:
        return []

    agents = chat.get("agents", [])
    result = []
    for agent in agents:
        data = agent.get("data", {})
        result.append(data.get("loaded_skills", []))
    return result


class TestAgent0LoadsUsingAgentSkills:
    """Agent 0 should have using-agent-skills in loaded_skills when opted in."""

    def test_agent0_loads_using_agent_skills_when_opted_in(
        self, a0_client: A0E2EClient, task_tracker, clean_tasks
    ):
        """Create a project with agent_skills_enabled: true, start a task,
        wait for completion, then verify agent 0's loaded_skills contains
        'using-agent-skills'.

        Steps:
        1. Create temp project with agent_skills_enabled in project.json
        2. Start a simple task on that project
        3. Wait for task to reach idle state
        4. Inspect chat.json → agents[0].data.loaded_skills
        5. Assert 'using-agent-skills' is present
        6. Clean up temp project and task
        """
        project_name, project_dir = _create_opted_in_project(a0_client)
        try:
            task = a0_client.create_and_run_task(
                name=f"e2e-agent-init-0-{uuid.uuid4().hex[:6]}",
                prompt="Say hello. Just respond with 'Hello from agent init test.'",
                project_name=project_name,
            )
            task_tracker.append(task["uuid"])
            result = a0_client.wait_for_task(task["uuid"], timeout=600)

            # Layer 1: task completed
            assert result.get("state") == "idle", (
                f"Task ended in state {result.get('state')}"
            )

            evidence = gather_evidence(a0_client, result)

            # Layer 3: no unexpected errors
            assert evidence["log_errors"] == 0, (
                f"Unexpected errors in logs: {evidence['log_errors']}"
            )

            # Layer 2: loaded_skills contains using-agent-skills
            context_id = evidence["context_id"]
            loaded = _get_loaded_skills_for_agent(a0_client, context_id, agent_index=0)
            assert "using-agent-skills" in loaded, (
                f"Expected 'using-agent-skills' in agent 0 loaded_skills, "
                f"got: {loaded}"
            )
        finally:
            _cleanup_project(project_dir)


class TestSubordinateNotAutoLoaded:
    """Subordinate agents should NOT auto-receive using-agent-skills."""

    def test_subordinate_not_auto_loaded(
        self, a0_client: A0E2EClient, task_tracker, clean_tasks
    ):
        """Create a project with agent_skills_enabled: true, start a task that
        delegates to a subordinate, then verify the subordinate's loaded_skills
        does NOT contain 'using-agent-skills'.

        Steps:
        1. Create temp project with agent_skills_enabled in project.json
        2. Start a task that triggers call_subordinate
        3. Wait for task to reach idle state
        4. Inspect chat.json → agents[1+].data.loaded_skills
        5. Assert 'using-agent-skills' is NOT in subordinate loaded_skills
        6. Clean up temp project and task
        """
        project_name, project_dir = _create_opted_in_project(a0_client)
        try:
            task = a0_client.create_and_run_task(
                name=f"e2e-agent-init-sub-{uuid.uuid4().hex[:6]}",
                prompt=(
                    "Delegate a trivial task to a subordinate using call_subordinate. "
                    "The subordinate should simply respond with 'Subordinate here.' "
                    "Then report what the subordinate said."
                ),
                project_name=project_name,
            )
            task_tracker.append(task["uuid"])
            result = a0_client.wait_for_task(task["uuid"], timeout=600)

            # Layer 1: task completed
            assert result.get("state") == "idle", (
                f"Task ended in state {result.get('state')}"
            )

            evidence = gather_evidence(a0_client, result)

            # Layer 3: no unexpected errors
            assert evidence["log_errors"] == 0, (
                f"Unexpected errors in logs: {evidence['log_errors']}"
            )

            # Layer 2: subordinate agents must not have using-agent-skills
            context_id = evidence["context_id"]
            all_skills = _get_all_agent_loaded_skills(a0_client, context_id)

            # Must have at least 2 agents (agent 0 + subordinate)
            assert len(all_skills) >= 2, (
                f"Expected at least 2 agents (superior + subordinate), "
                f"got {len(all_skills)}. The test requires a subordinate to be spawned."
            )

            for idx, skills in enumerate(all_skills[1:], start=1):
                assert "using-agent-skills" not in skills, (
                    f"Agent {idx} (subordinate) should NOT have 'using-agent-skills' "
                    f"in loaded_skills, got: {skills}"
                )
        finally:
            _cleanup_project(project_dir)
