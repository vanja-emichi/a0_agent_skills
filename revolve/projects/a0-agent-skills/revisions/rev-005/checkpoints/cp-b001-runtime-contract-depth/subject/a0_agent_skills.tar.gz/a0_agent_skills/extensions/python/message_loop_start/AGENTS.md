# message_loop_start Extensions

## Purpose

Extensions that fire at the start of each agent message loop iteration, before tools execute.

## Ownership

- `_10_load_using_agent_skills.py`: Auto-loads the `using-agent-skills` meta-skill for agent 0 when the project opts in via `agent_skills_enabled: true` in project.json.

## Local Contracts

- Extensions only run for agent number 0 on the first loop iteration (iteration 0).
- The `using-agent-skills` skill is registered in `agent.data['loaded_skills']` and a system message is injected.
- Project opt-in is required via `agent_skills_enabled: true` in project.json header.

## Work Guidance

- Add new message-loop-start hooks by creating `_NN_<name>.py` with the next available prefix number.
- Keep hooks focused on a single concern.

## Verification

- `tests/test_message_loop_start.py` covers extension behavior.

## Child DOX Index

No child DOX files.