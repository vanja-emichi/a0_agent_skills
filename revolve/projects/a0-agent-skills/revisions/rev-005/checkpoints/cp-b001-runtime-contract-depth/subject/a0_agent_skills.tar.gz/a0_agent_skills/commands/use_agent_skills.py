"""use-agent-skills command — initialize agent skills for the current project.

Checks whether the project has opted in to agent skills. On first run,
returns instructions for the agent to enable the opt-in flag. On
subsequent runs, confirms the skill is active.
"""


def run(payload):
    """Return initialization instructions for the agent to execute.

    The commands plugin calls run(payload) for script-type commands.
    The returned string becomes the agent's user message.
    """
    project_name = payload.get("context", {}).get("project_name", "")

    if not project_name:
        return (
            "No active project found. Switch to a project first, "
            "then run `/use-agent-skills` again."
        )

    # Check current opt-in state
    already_enabled = False
    try:
        from helpers.projects import load_project_header
        header = load_project_header(project_name)
        already_enabled = header.get("agent_skills_enabled") is True
    except Exception:
        already_enabled = False

    if already_enabled:
        return _already_enabled_message(project_name)

    return _first_run_message(project_name)


def _first_run_message(project_name):
    """Return instructions for the agent to execute on first run."""
    parts = []

    parts.append(
        f"Enable agent skills for project **{project_name}**.\n\n"
    )

    parts.append("## Step 1 — Opt in\n\n")
    parts.append(
        "Run this Python code via `code_execution_tool` to set the opt-in flag "
        "directly in the project JSON (the `update_project` helper drops unknown keys):\n\n"
    )
    parts.append("```python\n")
    parts.append("import json, os\n")
    parts.append(f'path = os.path.join("/a0/usr/projects", "{project_name}", ".a0proj", "project.json")\n')
    parts.append("with open(path) as f:\n")
    parts.append("    data = json.load(f)\n")
    parts.append('data["agent_skills_enabled"] = True\n')
    parts.append("with open(path, 'w') as f:\n")
    parts.append("    json.dump(data, f, indent=2)\n")
    parts.append('print("Done - agent_skills_enabled set to True")\n')
    parts.append("```\n\n")

    parts.append("## Step 2 — Explain to the user\n\n")
    parts.append(
        "After completing step 1, tell the user:\n"
        "- Agent skills are now enabled for this project\n"
        "- The `using-agent-skills` meta-skill will auto-load at session start\n"
        "- 23 engineering workflow skills are available via `skills_tool`\n"
        "- Run `/build`, `/spec`, `/plan`, `/test`, `/review`, or `/ship` "
        "for phase-driven workflows\n"
    )

    return "".join(parts)


def _already_enabled_message(project_name):
    """Return confirmation message when skills are already active."""
    parts = []

    parts.append(
        f"Agent skills are already enabled for project **{project_name}**.\n\n"
    )

    parts.append("**What's active:**\n")
    parts.append(
        "- `using-agent-skills` meta-skill auto-loads at session start\n"
    )
    parts.append("- 23 engineering workflow skills available via `skills_tool`\n")
    parts.append(
        "- Phase-driven slash commands: `/build`, `/spec`, `/plan`, "
        "`/test`, `/review`, `/ship`\n"
    )

    parts.append(
        "Use `skills_tool action search` to discover relevant skills, "
        "or `skills_tool action load` to load one.\n"
    )

    return "".join(parts)
