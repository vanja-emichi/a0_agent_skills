# tests/e2e

## Purpose
End-to-end behavioral tests for the a0_agent_skills plugin. All tests require a live Agent Zero HTTP API server on port 80.

## Ownership
Project team. Update when behavioral contracts change.

## Local Contracts
- `_a0_e2e_client.py` — shared HTTP client with auth and task polling
- `conftest.py` at `tests/` level — shared fixtures available here
- All test modules tagged `@pytest.mark.e2e`
- Extension behavior tests that create temp files MUST run sequentially (`-n 0`); other e2e tests can use `-n 4`
- Tests auto-skip when server unreachable

## Work Guidance
- Every new behavioral contract gets a corresponding e2e test module
- Use `A0E2EClient` for all HTTP interactions — never call the API directly
- Tests that modify project files (like routing migration tests) must backup/restore in `finally` blocks and carry the `routing_migration` marker

## Verification
```bash
/opt/venv/bin/python -m pytest tests/e2e -v -m e2e
```

## Child DOX Index
No further child AGENTS.md files.
