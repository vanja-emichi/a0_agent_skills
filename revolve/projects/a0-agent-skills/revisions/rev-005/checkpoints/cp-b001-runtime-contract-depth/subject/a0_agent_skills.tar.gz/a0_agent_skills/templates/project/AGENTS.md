# [Project Name]

## Purpose

[Describe what this project does]

## Ownership

[Who maintains this project]

## Local Contracts

| Working on [describe what] | Read [this file/doc] |
|---|---|
| _Add rows as you create documentation boundaries_ | |

## Work Guidance

_Leave empty until project-specific standards exist._

## Verification

_Leave empty until a verification framework exists._

## Child DOX Index

No child DOX files.

